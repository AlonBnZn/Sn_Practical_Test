﻿using Microsoft.EntityFrameworkCore;
using SilverNetAssignment.DAL.Configurations;
using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.DAL.Data
{
    public class SilverNetAssignmentContext : DbContext
    {
        public SilverNetAssignmentContext(DbContextOptions<SilverNetAssignmentContext> options)
     : base(options)
        {
        }
        public DbSet<Tenant> Tenants { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfiguration(new TenantConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());
        }
    }
}
