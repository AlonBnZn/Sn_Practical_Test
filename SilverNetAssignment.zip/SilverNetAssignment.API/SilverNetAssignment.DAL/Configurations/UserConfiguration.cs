﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.DAL.Configurations
{
    public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).ValueGeneratedOnAdd();
            builder.Property(u => u.FirstName).IsRequired(true).HasMaxLength(100);
            builder.Property(u => u.LastName).IsRequired(true).HasMaxLength(100);
            builder.Property(u => u.Phone).IsRequired(true).HasMaxLength(13);
            builder.Property(u => u.Email).IsRequired(true).HasMaxLength(200);
            builder.Property(u => u.CreationDate).IsRequired(true);
            builder.HasOne(u => u.Tenant).WithMany(t => t.Users).IsRequired(true);
        }
    }
}
