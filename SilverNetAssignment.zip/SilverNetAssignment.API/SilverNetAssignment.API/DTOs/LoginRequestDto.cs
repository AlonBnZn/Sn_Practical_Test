﻿namespace SilverNetAssignment.API.DTOs
{
    public class LoginRequestDto
    {
        public long TenantId { get; set; }
        public long? UserId { get; set; }
    }

}

