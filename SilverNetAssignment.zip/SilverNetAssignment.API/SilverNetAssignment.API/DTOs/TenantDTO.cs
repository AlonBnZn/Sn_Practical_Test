﻿namespace SilverNetAssignment.API.DTOs
{
    public class TenantDTO
    {
        public string name { get; set; } = null!;

        public string Phone { get; set; } = null!;

        public string Email { get; set; } = null!;

    }
}
