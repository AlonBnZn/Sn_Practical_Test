﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SilverNetAssignment.API.Authorization;
using SilverNetAssignment.API.DTOs;
using SilverNetAssignment.BLL.Services;

namespace SilverNetAssignment.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TenantController : ControllerBase
    {
        private ITenantService _tenantService;
        public TenantController(ITenantService tenantService)
        {
            _tenantService = tenantService;
        }

        [HttpGet("{id}")]
        [Authorize(Policy = Policies.Tenant)]
        public async Task<IActionResult> GetTenantById(long id)
        {
            var tenant = await _tenantService.GetTenantById(id);
            if (tenant == null)
            {
                return NotFound();
            }
            return Ok(tenant);
        }

        [HttpGet]
        [Authorize(Policy = Policies.Tenant)]
        public async Task<IActionResult> GetAllTenants()
        {
            var tenants = await _tenantService.GetAllTenants();
            return Ok(tenants);
        }

        [HttpPost]
        [Authorize(Policy = Policies.Tenant)]
        public async Task<IActionResult> CreateTenant([FromBody] TenantDTO tenantDTO)
        {
            var tenant = await _tenantService.CreateTenant(tenantDTO.name, tenantDTO.Phone, tenantDTO.Email);
            return CreatedAtAction(nameof(GetTenantById), new { id = tenant.Id }, tenantDTO);
        }

        [HttpPut("{id}")]
        [Authorize(Policy = Policies.Tenant)]
        public async Task<IActionResult> UpdateTenant(long id, [FromBody] TenantDTO tenantDTO)
        {
            await _tenantService.UpdateTenant(id, tenantDTO.name, tenantDTO.Phone, tenantDTO.Email);
            return NoContent();
        }

        [HttpDelete("{id}")]
        [Authorize(Policy = Policies.Tenant)]
        public async Task<IActionResult> DeleteTenant(long id)
        {
            await _tenantService.DeleteTenant(id);
            return NoContent();
        }

        [HttpGet("export/csv")]
        [Authorize(Policy = Policies.Tenant)]
        public async Task<IActionResult> ExportToCsv()
        {
            var csvBytes = await _tenantService.ExportTenantsToCSv();

            return File(
                csvBytes,
                "text/csv",
                $"tenants_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            );
        }
    }
}
