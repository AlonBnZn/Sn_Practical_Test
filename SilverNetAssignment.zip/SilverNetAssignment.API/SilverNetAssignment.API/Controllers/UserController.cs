﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SilverNetAssignment.API.Authorization;
using SilverNetAssignment.BLL.Services;
using SilverNetAssignment.DTOs;

namespace SilverNetAssignment.API.Controllers
{
    [Route("api/")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("tenants/{tenantId}/users/{id}")]
        [Authorize(Policy = Policies.User)]
        public async Task<IActionResult> GetUserById([FromRoute] long id, [FromRoute] long tenantId)
        {
            var user = await _userService.GetUserById(id, tenantId);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }

        [HttpGet("tenants/{tenantId}/users")]
        [Authorize(Policy = Policies.User)]
        public async Task<IActionResult> GetAllUsers([FromRoute] long tenantId)
        {
            var users = await _userService.GetAllUsers(tenantId);
            return Ok(users);
        }

        [HttpPost("tenants/{tenantId}/users")]
        [Authorize(Policy = Policies.User)]
        public async Task<IActionResult> CreateUser([FromBody] UserDTO userDto, [FromRoute] long tenantId)
        {
            var user = await _userService.CreateUser(tenantId, userDto.FirstName, userDto.LastName, userDto.Phone, userDto.Email);
            return CreatedAtAction(nameof(GetUserById), new { id = user.Id }, userDto);
        }

        [HttpPut("tenants/{tenantId}/users/{id}")]
        [Authorize(Policy = Policies.User)]
        public async Task<IActionResult> UpdateUser([FromRoute] long id, [FromRoute] long tenantId, [FromBody] UserDTO userDto)
        {
            await _userService.UpdateUser(id, tenantId, userDto.FirstName, userDto.LastName, userDto.Phone, userDto.Email);
            return NoContent();
        }

        [HttpDelete("tenants/{tenantId}/users/{id}")]
        [Authorize(Policy = Policies.User)]
        public async Task<IActionResult> DeleteUser([FromRoute] long id, [FromRoute] long tenantId)
        {
            await _userService.DeleteUser(id, tenantId);
            return NoContent();
        }

    }
}
