﻿using Microsoft.AspNetCore.Authorization;

namespace SilverNetAssignment.API.Authorization
{
    public class Requirements
    {
        public class UserRequirement : IAuthorizationRequirement { };
        public class TenantRequirement : IAuthorizationRequirement { };

    }
}
