﻿namespace SilverNetAssignment.API.Authorization
{
    public class Policies
    {
        public const string User = "User";

        public const string Tenant = "Tenant";
    }
}
