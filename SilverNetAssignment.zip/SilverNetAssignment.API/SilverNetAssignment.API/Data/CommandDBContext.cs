﻿using Microsoft.EntityFrameworkCore;
using SilverNetAssignment.DAL.Configurations;
using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.API.Data
{
    public class CommandDBContext : DbContext
    {
        public CommandDBContext(DbContextOptions<CommandDBContext> options)
     : base(options)
        {
        }
        public DbSet<Tenant> Tenants { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfiguration(new TenantConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());
        }
    }
}
