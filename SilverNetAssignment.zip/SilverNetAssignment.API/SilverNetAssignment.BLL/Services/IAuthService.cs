﻿namespace SilverNetAssignment.BLL.Services
{
    public interface IAuthService
    {
        Task<string?> LoginAsync(long tenantId, long? userId);
    }
}
