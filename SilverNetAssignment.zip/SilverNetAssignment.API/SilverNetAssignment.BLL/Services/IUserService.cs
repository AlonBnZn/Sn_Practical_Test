﻿using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.BLL.Services
{
    public interface IUserService
    {
        public Task<User> CreateUser(long tenantId, string firstName, string lastName, string phone, string email);

        public Task UpdateUser(long id, long tenantId, string firstName, string lastName, string phone, string email);

        public Task<User?> GetUserById(long id, long tenantId);

        public Task<List<User>> GetAllUsers(long tenantId);

        public Task DeleteUser(long id, long tenantId);


    }
}
