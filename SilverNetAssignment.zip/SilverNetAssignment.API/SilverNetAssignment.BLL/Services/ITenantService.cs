﻿using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.BLL.Services
{
    public interface ITenantService
    {
        public Task<Tenant> CreateTenant(string name, string phone, string email);

        public Task UpdateTenant(long id, string name, string phone, string email);

        public Task<Tenant?> GetTenantById(long id);

        public Task<List<Tenant>> GetAllTenants();

        public Task DeleteTenant(long id);

        public Task<byte[]> ExportTenantsToCSv();
    }
}
