﻿using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;
using System.Text;

namespace SilverNetAssignment.BLL.helpers
{
    public static class CsvHelperExport
    {
        public static byte[] ExportToCsv<T>(IEnumerable<T> records)
        {
            using var memoryStream = new MemoryStream();
            using var streamWriter = new StreamWriter(memoryStream, Encoding.UTF8);
            using var csvWriter = new CsvWriter(streamWriter, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
            });

            csvWriter.WriteRecords(records);
            streamWriter.Flush();
            return memoryStream.ToArray();
        }
    }
}
