﻿namespace SilverNetAssignment.BLL.Validation
{
    public interface IUserValidation
    {
        void ValidateUser(string firstName, string lastName, string phone, string email);
    }
}
