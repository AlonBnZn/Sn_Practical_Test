﻿using Microsoft.Extensions.Logging;
using SilverNetAssignment.BLL.Validations;
using SilverNetAssignment.DAL.Entities;
using SilverNetAssignment.DAL.Repositories;

namespace SilverNetAssignment.BLL.Services
{
    public class TenantService : ITenantService
    {
        private ITenantRepository _tenantRepository;

        private ILogger<TenantService> _logger;

        private ITenantValidation _tenantValidation;

        public TenantService(ITenantRepository tenantRepository, ILogger<TenantService> logger, ITenantValidation tenantValidation)
        {

            _logger = logger;

            _tenantRepository = tenantRepository;

            _tenantValidation = tenantValidation;
        }
        public async Task<Tenant> CreateTenant(string name, string phone, string email)
        {
            try
            {
                _logger.LogInformation("Creating tenant with email: {Email}", email);

                _tenantValidation.ValidateTenant(name, phone, email);

                Tenant tenant = new Tenant(name, phone, email);

                await _tenantRepository.CreateTenantAsync(tenant);

                _logger.LogInformation("Tenant created with email: {Email}", email);

                return tenant;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating tenant");

                throw new Exception("Error creating tenant", ex);
            }
        }

        public async Task DeleteTenant(long id)
        {
            try
            {
                _logger.LogInformation("Deleting tenant...");

                Tenant? tenant = await _tenantRepository.GetTenantByIdAsync(id);

                if (tenant is null)
                {
                    _logger.LogError("Tenant not found");

                    throw new Exception("Tenant not found");
                }
                await _tenantRepository.DeleteTenantAsync(tenant.Id);

                _logger.LogInformation("Finished Deleting tenant:{userId}", tenant.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Deleting tenant failed :" + ex.Message);

                throw new Exception("Error Deleting tenant", ex);

            }
        }

        public async Task<List<Tenant>> GetAllTenants()
        {
            try
            {
                _logger.LogInformation("Getting all tenants...");

                List<Tenant> tenants = await _tenantRepository.GetAllTenantsAsync();

                _logger.LogInformation("Finished Getting all tenants");

                return tenants;

            }
            catch (Exception ex)
            {
                _logger.LogError("Getting all tenants failed :" + ex.Message);

                throw new Exception("Getting all tenants failed", ex);
            }
        }

        public async Task<Tenant?> GetTenantById(long id)
        {
            try
            {
                _logger.LogInformation("Getting tenant by id...");

                Tenant? tenant = await _tenantRepository.GetTenantByIdAsync(id);

                if (tenant is null)
                {
                    _logger.LogError("Tenant not found");

                    throw new Exception("Tenant not found");
                }

                _logger.LogInformation("Finished Getting tenant {userId}", id);

                return tenant;

            }
            catch (Exception ex)
            {
                _logger.LogError("Getting tenant by id failed :" + ex.Message);
                throw new Exception("Getting tenant by id failed", ex);
            }
        }

        public async Task UpdateTenant(long id, string name, string phone, string email)
        {
            try
            {
                _logger.LogInformation("Updating user with id: {id}", id);

                _tenantValidation.ValidateTenant(name, phone, email);

                Tenant? tenant = await _tenantRepository.GetTenantByIdAsync(id);

                if (tenant is null)
                {
                    _logger.LogError("Tenant not found");

                    throw new Exception("Tenant not found");
                }

                tenant.SetName(name);

                tenant.SetPhone(phone);

                tenant.SetEmail(email);

                await _tenantRepository.UpdateTenantAsync(tenant);
            }
            catch (Exception ex)
            {
                _logger.LogError("Updating tenant failed :" + ex.Message);

                throw new Exception("Error updating tenant", ex);
            }
        }
    }
}
