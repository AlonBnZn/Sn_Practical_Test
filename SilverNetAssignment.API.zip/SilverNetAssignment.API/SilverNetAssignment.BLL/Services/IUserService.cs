﻿using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.BLL.Services
{
    public interface IUserService
    {
        public Task<User> CreateUser(string firstName, string lastName, string phone, string email);

        public Task UpdateUser(long id, string firstName, string lastName, string phone, string email);

        public Task<User?> GetUserById(long id);

        public Task<List<User>> GetAllUsers();

        public Task DeleteUser(long id);

    }
}
