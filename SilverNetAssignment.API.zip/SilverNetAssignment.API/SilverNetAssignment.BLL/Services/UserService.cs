﻿using Microsoft.Extensions.Logging;
using SilverNetAssignment.BLL.Validation;
using SilverNetAssignment.DAL.Entities;
using SilverNetAssignment.DAL.Repositories;

namespace SilverNetAssignment.BLL.Services
{
    public class UserService : IUserService
    {
        private IUserRepository _userRepository;

        private ITenantRepository _tenantRepository;

        private ILogger<UserService> _logger;

        private IUserValidation _userValidation;

        public UserService(IUserRepository userRepository, ITenantRepository tenantRepository, ILogger<UserService> logger, IUserValidation userValidation)
        {
            _logger = logger;

            _userRepository = userRepository;

            _tenantRepository = tenantRepository;

            _userValidation = userValidation;
        }

        public async Task<User> CreateUser(string firstName, string lastName, string phone, string email, long tenantId)
        {
            try
            {
                _logger.LogInformation("Creating user with email: {Email}", email);

                Tenant? tenant = await _tenantRepository.GetTenantByIdAsync(tenantId);

                if (tenant is null)
                {
                    _logger.LogError("Tenant with id {TenantId} not found", tenantId);
                    throw new Exception($"Tenant with id {tenantId} not found");
                }

                _userValidation.ValidateUser(firstName, lastName, phone, email);

                User user = new User(firstName, lastName, phone, email);

                user.Tenant = tenant;

                await _userRepository.CreateUserAsync(user);

                _logger.LogInformation("User created with email: {Email}", email);

                return user;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating user");
                throw new Exception("Error creating user", ex);
            }
        }


        public async Task DeleteUser(long id)
        {
            try
            {
                _logger.LogInformation("Deleting user...");

                User? user = await _userRepository.GetUserByIdAsync(id);

                if (user is null)
                {
                    _logger.LogError("User not found");

                    throw new Exception("User not found");
                }
                await _userRepository.DeleteUserAsync(user.Id);

                _logger.LogInformation("Finished Deleting user:{userId}", user.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError("Deleting user failed :" + ex.Message);

                throw new Exception("Error Deleting user", ex);

            }
        }

        public async Task<List<User>> GetAllUsers()
        {
            try
            {
                _logger.LogInformation("Getting all users...");

                List<User> users = await _userRepository.GetAllUsersAsync();

                _logger.LogInformation("Finished Getting all users");

                return users;

            }
            catch (Exception ex)
            {
                _logger.LogError("Getting all users failed :" + ex.Message);

                throw new Exception("Getting all users failed", ex);
            }
        }

        public async Task<User?> GetUserById(long id)
        {
            try
            {
                _logger.LogInformation("Getting user by id...");

                User? user = await _userRepository.GetUserByIdAsync(id);

                if (user is null)
                {
                    _logger.LogError("User not found");

                    throw new Exception("User not found");
                }

                _logger.LogInformation("Finished Getting user {userId}", id);

                return user;

            }
            catch (Exception ex)
            {
                _logger.LogError("Getting user by id failed :" + ex.Message);
                throw new Exception("Getting user by id failed", ex);
            }
        }

        public async Task UpdateUser(long id, string firstName, string lastName, string phone, string email)
        {
            try
            {
                _logger.LogInformation("Updating user with id: {id}", id);

                _userValidation.ValidateUser(firstName, lastName, phone, email);

                User? user = await _userRepository.GetUserByIdAsync(id);

                if (user is null)
                {
                    _logger.LogError("User not found");

                    throw new Exception("User not found");
                }

                user.SetFirstName(firstName);

                user.SetLastName(lastName);

                user.SetPhone(phone);

                user.SetEmail(email);

                await _userRepository.UpdateUserAsync(user);
            }
            catch (Exception ex)
            {
                _logger.LogError("Updating user failed :" + ex.Message);

                throw new Exception("Error updating user", ex);
            }
        }
        public async Task<List<User>> GetUsersByTenantId(long tenantId)
        {
            try
            {
                _logger.LogInformation("Getting all users for tenant: {TenantId}", tenantId);
                Tenant? tenant = await _tenantRepository.GetTenantByIdAsync(tenantId);

                if (tenant is null)
                {
                    _logger.LogError("Tenant not found with id: {TenantId}", tenantId);

                    throw new Exception($"Tenant with id {tenantId} not found");
                }

                List<User> users = await _userRepository.GetUsersByTenantIdAsync(tenantId);

                _logger.LogInformation("Finished getting {Count} users for tenant: {TenantId}", users.Count, tenantId);

                return users;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Getting users by tenant id failed: {Message}", ex.Message);

                throw new Exception("Error getting users by tenant id", ex);
            }
        }
    }
}
