﻿namespace SilverNetAssignment.BLL.helpers
{
    public static class CsvHelper
    {
        //public static async Task<IList<T>> ReadCsvFileAsync<T>(T file)
        //{
        //    if (file == null || file.Length == 0)
        //    {
        //        throw new ArgumentException("File is empty or null.");
        //    }
        //    using var reader = new StreamReader(file.OpenReadStream());
        //    string content = await reader.ReadToEndAsync();
        //    return content;
        //}
    }
}
