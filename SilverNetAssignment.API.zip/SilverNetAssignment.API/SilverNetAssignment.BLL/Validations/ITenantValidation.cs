﻿namespace SilverNetAssignment.BLL.Validations
{
    public interface ITenantValidation
    {
        void ValidateTenant(string name, string phone, string email);

    }
}
