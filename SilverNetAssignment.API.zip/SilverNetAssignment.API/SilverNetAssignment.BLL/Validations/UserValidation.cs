﻿using SilverNetAssignment.BLL.Validations;

namespace SilverNetAssignment.BLL.Validation
{
    public class UserValidation : IUserValidation
    {
        public void ValidateUser(string firstName, string lastName, string phone, string email)
        {
            if (string.IsNullOrWhiteSpace(firstName) || firstName.Length < 2)
            {
                throw new ArgumentException("First name must be at least 2 characters long.");
            }

            if (string.IsNullOrWhiteSpace(lastName) || lastName.Length < 2)
            {
                throw new ArgumentException("Last name must be at least 2 characters long.");
            }

            EmailValidation.ValidateEmail(email);

            PhoneValidation.ValidatePhone(phone);
        }
    }
}
