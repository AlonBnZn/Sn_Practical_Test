﻿namespace SilverNetAssignment.BLL.Validations
{
    public class TenantValidation : ITenantValidation
    {
        public void ValidateTenant(string name, string phone, string email)
        {
            if (string.IsNullOrWhiteSpace(name) || name.Length < 2)
            {
                throw new ArgumentException("Name must be at least 2 characters long.");
            }

            EmailValidation.ValidateEmail(email);

            PhoneValidation.ValidatePhone(phone);
        }
    }
}
