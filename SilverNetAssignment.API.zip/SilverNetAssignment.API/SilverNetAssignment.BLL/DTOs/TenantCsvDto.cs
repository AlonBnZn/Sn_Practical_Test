﻿using CsvHelper.Configuration.Attributes;

namespace SilverNetAssignment.BLL.DTOs
{
    public class TenantCsvDto
    {
        [Name("Tenant ID")]
        public long Id { get; set; }

        [Name("Tenant Name")]
        public string Name { get; set; }

        [Name("Email")]
        public string Email { get; set; }

        [Name("Phone")]
        public string Phone { get; set; }


        [Name("Created Date")]
        [Format("yyyy-MM-dd")]
        public DateTime CreatedDate { get; set; }
    }

}
