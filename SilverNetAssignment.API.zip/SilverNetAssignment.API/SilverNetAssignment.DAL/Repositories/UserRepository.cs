﻿using Microsoft.EntityFrameworkCore;
using SilverNetAssignment.DAL.Data;
using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.DAL.Repositories
{
    public class UserRepository : IUserRepository
    {

        private SilverNetAssignmentContext _DBContext;

        public UserRepository(SilverNetAssignmentContext dbContext)
        {
            _DBContext = dbContext;
        }

        public async Task<long> CreateUserAsync(User user)
        {
            await _DBContext.Users.AddAsync(user);

            await _DBContext.SaveChangesAsync();

            return user.Id;
        }

        public async Task DeleteUserAsync(long userId)
        {
            User? user = await _DBContext.Users.FindAsync(userId);

            if (user == null)
            {
                throw new KeyNotFoundException($"User with id {userId} was not found.");
            }

            _DBContext.Users.Remove(user);

            await _DBContext.SaveChangesAsync();
        }

        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _DBContext.Users.ToListAsync();
        }

        public async Task<User?> GetUserByIdAsync(long userId)
        {
            User? user = await _DBContext.Users.FirstAsync(u => u.Id == userId);

            if (user == null)
            {
                throw new KeyNotFoundException($"Tenant with id {userId} was not found.");
            }

            return user;
        }

        public async Task UpdateUserAsync(User user)
        {
            _DBContext.Users.Update(user);
            await _DBContext.SaveChangesAsync();
        }
    }
}
