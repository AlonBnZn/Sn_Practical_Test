﻿using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.DAL.Repositories
{
    public interface IUserRepository
    {
        public Task<long> CreateUserAsync(User user);

        public Task<User?> GetUserByIdAsync(long userId);

        public Task<List<User>> GetAllUsersAsync();

        public Task UpdateUserAsync(User user);

        public Task DeleteUserAsync(long userId);
        public Task<List<User>> GetUsersByTenantIdAsync(long TanentId);
    }
}
