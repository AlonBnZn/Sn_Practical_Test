﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SilverNetAssignment.DAL.Entities;

namespace SilverNetAssignment.DAL.Configurations
{
    public class TenantConfiguration : IEntityTypeConfiguration<Tenant>
    {
        public void Configure(EntityTypeBuilder<Tenant> builder)
        {
            builder.HasKey(t => t.Id);
            builder.Property(t => t.Id).ValueGeneratedOnAdd();
            builder.Property(t => t.Name).IsRequired(true);
            builder.Property(t => t.Phone).IsRequired(true);
            builder.Property(t => t.Email).IsRequired(true);
            builder.Property(t => t.CreationDate).IsRequired(true);
            builder.HasMany(t => t.Users).WithOne(u => u.Tenant).IsRequired(true);

        }
    }
}
