using Microsoft.EntityFrameworkCore;
using Serilog;
using SilverNetAssignment.API.Data;
using SilverNetAssignment.BLL.Services;
using SilverNetAssignment.BLL.Validation;
using SilverNetAssignment.BLL.Validations;
using SilverNetAssignment.DAL.Data;
using SilverNetAssignment.DAL.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddDbContext<SilverNetAssignmentContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddDbContext<CommandDBContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Host.UseSerilog((context, config) =>
{
    config.ReadFrom.Configuration(context.Configuration);
});

builder.Services.AddScoped<IUserValidation, UserValidation>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IUserRepository, UserRepository>();

builder.Services.AddScoped<ITenantRepository, TenantRepository>();
builder.Services.AddScoped<ITenantService, TenantService>();
builder.Services.AddScoped<ITenantValidation, TenantValidation>();

var app = builder.Build();

// Configure the HTTP request pipeline.


app.UseAuthorization();

app.MapControllers();

app.UseRouting();

app.Run();
