﻿using Microsoft.AspNetCore.Mvc;
using SilverNetAssignment.API.DTOs;
using SilverNetAssignment.BLL.Services;

namespace SilverNetAssignment.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TenantController : ControllerBase
    {
        private ITenantService _tenantService;
        public TenantController(ITenantService tenantService)
        {
            _tenantService = tenantService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTenantById(long id)
        {
            var tenant = await _tenantService.GetTenantById(id);
            if (tenant == null)
            {
                return NotFound();
            }
            return Ok(tenant);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            var tenants = await _tenantService.GetAllTenants();
            return Ok(tenants);
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] TenantDTO tenantDTO)
        {
            var tenant = await _tenantService.CreateTenant(tenantDTO.name, tenantDTO.Phone, tenantDTO.Email);
            return CreatedAtAction(nameof(GetTenantById), new { id = tenant.Id }, tenantDTO);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(long id, [FromBody] TenantDTO tenantDTO)
        {
            await _tenantService.UpdateTenant(id, tenantDTO.name, tenantDTO.Phone, tenantDTO.Email);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(long id)
        {
            await _tenantService.DeleteTenant(id);
            return NoContent();
        }

        [HttpGet("export/csv")]
        public async Task<IActionResult> ExportToCsv()
        {
            var csvBytes = await _tenantService.ExportTenantsToCSv();

            return File(
                csvBytes,
                "text/csv",
                $"tenants_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            );
        }
    }
}
